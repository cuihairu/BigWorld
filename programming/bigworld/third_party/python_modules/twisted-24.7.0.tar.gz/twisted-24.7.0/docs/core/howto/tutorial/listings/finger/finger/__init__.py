"""
Finger example application.
"""
